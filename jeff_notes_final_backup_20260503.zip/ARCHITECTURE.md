# Jeff Notes: Academic Intelligence Pipeline Architecture

本文档记录了 Jeff Notes 的核心算力混编架构与硬件级优化细节。

## 1. 核心算力混编图谱 (Quad-Tier Orchestration)

App 采用了多供应商、多模型协同的“混编模式”，根据任务特性动态分配算力：

| 任务轨道 | 处理动作 | 模型选择 | 平台来源 | 核心优势 |
| :--- | :--- | :--- | :--- | :--- |
| **STT (转录)** | 5s 音频 -> 文本 | **SenseVoiceSmall** | SiliconFlow | 极速响应，抗底噪能力强 |
| **Track 1 (翻译)** | 英文 -> 纯净中文 | **Llama-3.3-70b** | **Groq** | 毫秒级推理，彻底告别乱码 |
| **Track 2 (小结)** | 60s 考点提取 | **Qwen-2.5-72B** | SiliconFlow | 学术深度与速度的黄金平衡 |
| **Track 3 (复盘)** | 全篇逻辑重构 | **DeepSeek-V3** | SiliconFlow | 行业顶级推理，大师级报告 |

## 2. 硬件级音频工程 (Acoustic Engineering)

为了确保 AI 能听清每一句讲座细节，App 针对 iOS 进行了底层加固：

- **编码格式**：由 AAC 升级为 **16-bit PCM (WAV)**，提供识别率最高的“母带级”音质。
- **采样对齐**：强制 **16,000Hz 单声道**，完美契合语音大模型的预训练频段。
- **iOS 模式**：激活 **`AVAudioSessionModeVoiceChat`**。
    - 物理级激活 iPhone 硬件降噪。
    - 开启自动增益补偿 (AGC)，动态放大导师声音。
- **AirPods 专项**：支持 `allowBluetooth` 协议，佩戴耳机时自动接管指向性麦克风。

## 3. UI/UX 交互美学

- **1/3 黄金分割**：顶部 30% 为 Insight 面板（显示 Track 2），底部 70% 为流式字幕。
- **学术级排版**：
    - 字幕采用 `w600` 半粗体，行高 1.5。
    - 中文翻译配以 **左侧蓝色装饰条**，形成块级视觉区分。
- **噪声过滤**：内置语义过滤器，自动拦截 "Yeah", "Uh-huh" 等幻觉噪声碎片。

## 4. 经济性与稳定性

- **错峰调度**：翻译延迟 500ms，小结延迟 1s，有效规避高并发下的 API 限制（429）。
- **零配置启动**：预设 SiliconFlow 与 Groq API Keys，开箱即用。
- **成本优化**：小时运行成本仅约 **0.5 RMB**，余额 30 元可支撑约 60~80 小时录音。

---
*Last Updated: 2026-05-03 (Final Build)*
