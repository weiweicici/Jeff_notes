import 'prompt_provider.dart';

class UserPreferenceManager {
  static final UserPreferenceManager _instance = UserPreferenceManager._internal();
  factory UserPreferenceManager() => _instance;
  UserPreferenceManager._internal();

  // 预留设置接口，默认使用 toeflIelts
  PromptStrategy currentPromptStrategy = PromptStrategy.toeflIelts;
  
  // 可以在这里扩展更多的设置项，如自定义模型名称、API BaseURL 等
}
