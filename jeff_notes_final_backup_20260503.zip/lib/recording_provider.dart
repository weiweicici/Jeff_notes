import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:record/record.dart';
import 'package:path_provider/path_provider.dart';
import 'package:audio_session/audio_session.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:intl/intl.dart';
import 'openai_service.dart';
import 'user_preference_manager.dart';
import 'package:google_mlkit_translation/google_mlkit_translation.dart';

class InsightNote {
  String summary;
  String transcript;
  String? translatedContent; 
  final DateTime timestamp;
  bool isProcessing;
  final String? clusterId;
  final bool isSummary;

  InsightNote({
    required this.summary,
    required this.transcript,
    this.translatedContent,
    required this.timestamp,
    this.isProcessing = false,
    this.clusterId,
    this.isSummary = false,
  });

  Map<String, dynamic> toJson() => {
    'summary': summary,
    'transcript': transcript,
    'translatedContent': translatedContent,
    'timestamp': timestamp.toIso8601String(),
    'clusterId': clusterId,
    'isSummary': isSummary,
  };

  factory InsightNote.fromJson(Map<String, dynamic> json) => InsightNote(
    summary: json['summary'],
    transcript: json['transcript'],
    translatedContent: json['translatedContent'],
    timestamp: DateTime.parse(json['timestamp']),
    clusterId: json['clusterId'],
    isSummary: json['isSummary'] ?? false,
  );
}

enum AIProvider { groq, siliconFlow }

class RecordingProvider extends ChangeNotifier {
  final AudioRecorder _audioRecorder = AudioRecorder();
  OpenAIService? _aiService;     // [Track 2/3: SiliconFlow 72B/DS]
  OpenAIService? _fastAiService; // [Track 1: SiliconFlow STT]
  OpenAIService? _groqService;   // [Track 1: Groq Translation]
  
  AIProvider _selectedProvider = AIProvider.groq;
  int _sliceDuration = 5; 
  bool _useBluetooth = false;
  bool _isDarkMode = false;
  bool _enableFinalRecap = false; // [Master Switch] 默认关闭全篇复盘
  final Map<AIProvider, String> _apiKeys = {
    AIProvider.siliconFlow: "sk-ovsutjuybcrndvdxfskcooqsfwpwgtxlqcnolnbssrzzaszi",
    AIProvider.groq: "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",
  };
  
  Timer? _sliceTimer;
  bool _isRecording = false;
  bool _isPending = false;
  
  final List<InsightNote> _allNotes = [];
  final List<String> _transcriptBuffer = [];
  final List<InsightNote> _noteBuffer = [];
  final List<String> _tempFilePaths = [];
  final List<InsightNote> _translationBuffer = []; // [Architect: 15s Aggregated Translation Buffer]
  
  final _onDeviceTranslator = OnDeviceTranslator(
    sourceLanguage: TranslateLanguage.english,
    targetLanguage: TranslateLanguage.chinese,
  );

  String? _statusMessage;
  String? _lastSummary;
  String? _finalReviewContent;
  bool _isGeneratingFinalReview = false; // [Logic Lock]
  String? _lastExportedPath;

  List<InsightNote> get notes {
    final summarizedClusterIds = _allNotes.where((n) => n.isSummary).map((n) => n.clusterId).toSet();
    return _allNotes.where((note) {
      if (note.isSummary) return true;
      if (note.clusterId == null) return true; 
      if (!summarizedClusterIds.contains(note.clusterId)) return true;
      return false;
    }).toList().reversed.toList();
  }

  bool get isRecording => _isRecording;
  bool get isPending => _isPending;
  AIProvider get selectedProvider => _selectedProvider;
  int get sliceDuration => _sliceDuration;
  bool get useBluetooth => _useBluetooth;
  bool get isDarkMode => _isDarkMode;
  bool get enableFinalRecap => _enableFinalRecap;
  String? get finalReviewContent => _finalReviewContent;
  bool get isGeneratingFinalReview => _isGeneratingFinalReview;
  String? get lastExportedPath => _lastExportedPath;
  String? get statusMessage => _statusMessage;

  // [Shadow Save] 恢复提示标记
  bool _hasRecoveredCache = false;
  bool get hasRecoveredCache => _hasRecoveredCache;

  RecordingProvider() { _init(); }

  Future<void> _init() async {
    try { 
      await _loadSettings(); 
      await _initializeAudioSession(); 
      await _checkRecoveryCache(); // [Shadow Save] 启动检测
    } 
    catch (e) { debugPrint('Init error: $e'); }
  }

  // [Shadow Save] 核心写入逻辑
  Future<void> _saveShadowCache() async {
    try {
      final directory = await getTemporaryDirectory();
      final file = File('${directory.path}/shadow_draft.json');
      final data = {
        'lastSummary': _lastSummary,
        'notes': _allNotes.map((n) => n.toJson()).toList(),
      };
      await file.writeAsString(jsonEncode(data));
      debugPrint("[Shadow Cache] Draft stored with context.");
    } catch (e) { debugPrint("Shadow Save Error: $e"); }
  }

  Future<void> _clearShadowCache() async {
    try {
      final directory = await getTemporaryDirectory();
      final file = File('${directory.path}/shadow_draft.json');
      if (await file.exists()) await file.delete();
      _hasRecoveredCache = false;
      notifyListeners();
    } catch (e) { debugPrint("Clear Cache Error: $e"); }
  }

  Future<void> _checkRecoveryCache() async {
    try {
      final directory = await getTemporaryDirectory();
      final file = File('${directory.path}/shadow_draft.json');
      if (await file.exists()) {
        _hasRecoveredCache = true;
        notifyListeners();
      }
    } catch (e) { debugPrint("Recovery Check Error: $e"); }
  }

  Future<void> recoverFromCache() async {
    try {
      final directory = await getTemporaryDirectory();
      final file = File('${directory.path}/shadow_draft.json');
      if (await file.exists()) {
        final content = await file.readAsString();
        final Map<String, dynamic> data = jsonDecode(content);
        
        _lastSummary = data['lastSummary'];
        final List<dynamic> notesData = data['notes'];
        
        _allNotes.clear();
        _allNotes.addAll(notesData.map((item) => InsightNote.fromJson(item)).toList());
        
        _hasRecoveredCache = false;
        notifyListeners();
        debugPrint("[Shadow Cache] Context & Notes recovered.");
      }
    } catch (e) { debugPrint("Recovery Execution Error: $e"); }
  }
  
  void dismissRecovery() { _clearShadowCache(); }

  // [Architect's Abandon Logic] 彻底放弃当前 Session 及其影子文件
  Future<void> discardActiveSession() async {
    _isRecording = false;
    _sliceTimer?.cancel();
    _sliceTimer = null;
    await _audioRecorder.stop();
    
    _allNotes.clear();
    _transcriptBuffer.clear();
    _noteBuffer.clear();
    _lastSummary = null;
    _finalReviewContent = null;
    
    await _cleanupTempFiles();
    await _clearShadowCache();
    notifyListeners();
  }

  Future<void> _loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    _sliceDuration = prefs.getInt('slice_duration') ?? 5;
    _useBluetooth = prefs.getBool('use_bluetooth') ?? false;
    _isDarkMode = prefs.getBool('is_dark_mode') ?? false;
    _enableFinalRecap = prefs.getBool('enable_final_recap') ?? false;
    for (var p in AIProvider.values) {
      String? key = prefs.getString('api_key_${p.name}');
      if (p == AIProvider.groq && key == null) key = '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';
      if (p == AIProvider.siliconFlow && (key == null || key.isEmpty)) key = 'sk-ovsutjuybcrndvdxfskcooqsfwpwgtxlqcnolnbssrzzaszi';
      if (key != null) _apiKeys[p] = key;
    }
    final providerIndex = prefs.getInt('selected_provider') ?? 0;
    _selectedProvider = (providerIndex < AIProvider.values.length) ? AIProvider.values[providerIndex] : AIProvider.groq;
    _updateService();
    notifyListeners();
  }

  void _updateService() {
    _aiService?.dispose();
    _fastAiService?.dispose();
    _groqService?.dispose();
    
    final siliconKey = _apiKeys[AIProvider.siliconFlow];
    final groqKey = _apiKeys[AIProvider.groq];

    // [Hybrid Strategy] 只要有硅基 Key，就激活学术分析大脑
    if (siliconKey != null && siliconKey.isNotEmpty) {
      // 1. [Track 2: Summary] Qwen 72B
      _aiService = OpenAIService(apiKey: siliconKey, baseUrl: "https://api.siliconflow.cn/v1", defaultModel: "Qwen/Qwen2.5-72B-Instruct", whisperModel: "FunAudioLLM/SenseVoiceSmall");
      // 2. [Track 1: STT] SenseVoice
      _fastAiService = OpenAIService(apiKey: siliconKey, baseUrl: "https://api.siliconflow.cn/v1", defaultModel: "Qwen/Qwen2.5-7B-Instruct", whisperModel: "FunAudioLLM/SenseVoiceSmall");
    }

    // [Hybrid Strategy] 只要有 Groq Key，就激活极速翻译引擎
    if (groqKey != null && groqKey.isNotEmpty) {
      // 3. [Track 1: Translation] Llama 3.3
      _groqService = OpenAIService(apiKey: groqKey, baseUrl: "https://api.groq.com/openai/v1", defaultModel: "llama-3.3-70b-versatile");
      
      // [Fallback] 如果没有硅基，Groq 也得承担总结任务
      if (_aiService == null) {
        _aiService = _groqService;
        _fastAiService = _groqService;
      }
    } else {
      // 如果没有 Groq，翻译任务自动降级到硅基的 Qwen 7B
      _groqService = null; 
    }
  }

  Future<void> updateSettings({AIProvider? provider, String? key, int? duration, bool? useBluetooth, bool? isDarkMode, bool? enableFinalRecap}) async {
    final prefs = await SharedPreferences.getInstance();
    if (duration != null) { await prefs.setInt('slice_duration', duration); _sliceDuration = duration; }
    if (useBluetooth != null) { await prefs.setBool('use_bluetooth', useBluetooth); _useBluetooth = useBluetooth; await _initializeAudioSession(); }
    if (isDarkMode != null) { await prefs.setBool('is_dark_mode', isDarkMode); _isDarkMode = isDarkMode; }
    if (enableFinalRecap != null) { await prefs.setBool('enable_final_recap', enableFinalRecap); _enableFinalRecap = enableFinalRecap; }
    if (provider != null) {
      await prefs.setInt('selected_provider', provider.index);
      _selectedProvider = provider;
      if (key != null) { await prefs.setString('api_key_${provider.name}', key); _apiKeys[provider] = key; }
    } else if (key != null) {
      await prefs.setString('api_key_${_selectedProvider.name}', key); _apiKeys[_selectedProvider] = key;
    }
    _updateService(); notifyListeners();
  }

  Future<void> _initializeAudioSession() async {
    final session = await AudioSession.instance;
    await session.configure(AudioSessionConfiguration(
      avAudioSessionCategory: AVAudioSessionCategory.playAndRecord,
      avAudioSessionCategoryOptions: _useBluetooth 
          ? (AVAudioSessionCategoryOptions.defaultToSpeaker | AVAudioSessionCategoryOptions.allowBluetooth) 
          : AVAudioSessionCategoryOptions.defaultToSpeaker,
      // [Architect: Source Control] 
      // 蓝牙关闭时，使用 measurement 模式强制回归手机内置麦克风
      // 蓝牙开启时，使用 voiceChat 模式全力支持耳机收音
      avAudioSessionMode: _useBluetooth ? AVAudioSessionMode.voiceChat : AVAudioSessionMode.measurement, 
      avAudioSessionRouteSharingPolicy: AVAudioSessionRouteSharingPolicy.defaultPolicy,
      avAudioSessionSetActiveOptions: AVAudioSessionSetActiveOptions.none,
    ));
    await session.setActive(true);
  }

  Future<void> toggleRecording() async {
    if (_isPending) return;
    _isPending = true;
    if (!_isRecording) { _finalReviewContent = null; _lastExportedPath = null; _statusMessage = null; await startRecording(); }
    else { await stopRecording(); }
    _isPending = false; notifyListeners();
  }

  Future<void> startRecording() async {
    if (await _audioRecorder.hasPermission()) {
      _isRecording = true; 
      _allNotes.clear(); _transcriptBuffer.clear(); _noteBuffer.clear();
      _lastSummary = null; 
      notifyListeners();
      await _startNewSlice();
      _scheduleNextSlice();
    }
  }

  void _scheduleNextSlice() {
    _sliceTimer?.cancel();
    if (!_isRecording) return;
    _sliceTimer = Timer(Duration(seconds: _sliceDuration), () async {
      await _rotateSlice();
      _scheduleNextSlice();
    });
  }

  @override
  void dispose() {
    _aiService?.dispose();
    _fastAiService?.dispose();
    _sliceTimer?.cancel();
    _audioRecorder.dispose();
    _onDeviceTranslator.close();
    super.dispose();
  }

  Future<void> _rotateSlice() async {
    if (!_isRecording) return;
    try {
      final path = await _audioRecorder.stop();
      await _startNewSlice();
      if (path != null) { 
        _tempFilePaths.add(path); // 追踪切片路径用于后续 GC
        debugPrint("[Disk] Buffered slice segment for processing: $path");
        await _processAudio(path); // [Sequential Logic] 必须顺序处理，确保计数器不跳号
      }
    } catch (e) { debugPrint('Rotate Error: $e'); }
  }

  Future<void> _startNewSlice() async {
    try {
      // [iOS Path Hardening] 使用 Documents 目录确保物理文件在内存紧张时不被系统清理
      final directory = await getApplicationDocumentsDirectory();
      final path = '${directory.path}/rec_${DateTime.now().millisecondsSinceEpoch}.wav';
      // [Academic Grade Config] 16kHz PCM 单声道是 Whisper 识别率最高的格式
      await _audioRecorder.start(
        const RecordConfig(
          encoder: AudioEncoder.wav, 
          sampleRate: 16000, 
          numChannels: 1,
          bitRate: 256000,
        ), 
        path: path
      );
    } catch (e) { debugPrint('[CRITICAL] Start Slice Error: $e'); }
  }

  Future<void> stopRecording() async {
    _isRecording = false; _sliceTimer?.cancel(); _sliceTimer = null;
    try {
      final path = await _audioRecorder.stop();
      if (path != null) { 
        _tempFilePaths.add(path); // 追踪最后一个切片
        await _processAudio(path); 
      }
      // [强制收割] 确保最后不足 60s 的内容也被总结入库
      if (_transcriptBuffer.isNotEmpty) {
        final combinedText = _transcriptBuffer.join(" ");
        final clusterId = _noteBuffer.isNotEmpty ? _noteBuffer.first.clusterId : "final_tail";
        _transcriptBuffer.clear();
        _noteBuffer.clear();
        await _performBatchSummary(combinedText, clusterId);
      }
      
      // [巅峰复盘] 仅在用户手动开启开关时启动
      if (_enableFinalRecap) {
        await generateFinalAcademicReview();
      } else {
        _finalReviewContent = "Final Recap is disabled in settings.";
        notifyListeners();
      }
      if (_translationBuffer.isNotEmpty) {
        final batch = List<InsightNote>.from(_translationBuffer);
        _translationBuffer.clear();
        await _performAggregatedTranslation(batch); // [Tail Treatment]
      }
      _lastSummary = null;
    } catch (e) { debugPrint('Stop Error: $e'); } finally { notifyListeners(); }
  }

  Future<void> _processAudio(String path) async {
    final service = _fastAiService ?? _aiService;
    if (service == null) return;
    try {
      final transcript = await service.transcribe(path);
      if (transcript == null || transcript.isEmpty) return;

      // [Architect: Noise Reduction] 核心策略：过滤无意义碎片或极短幻觉
      final cleanTranscript = transcript.trim();
      final noisePatterns = RegExp(r'^(yeah|oh|uh|ah|hmm|well|ok|right|sh|wch)\.?$', caseSensitive: false);
      
      if (cleanTranscript.length < 8 && noisePatterns.hasMatch(cleanTranscript)) {
        debugPrint("[Noise Filter] Dropped fragment: $cleanTranscript");
        return;
      }

      final currentClusterId = "cluster_${DateTime.now().millisecondsSinceEpoch ~/ 20000}"; 
      final note = InsightNote(summary: '', transcript: transcript, timestamp: DateTime.now(), clusterId: currentClusterId, isSummary: false);
      _allNotes.add(note);
      _noteBuffer.add(note);
      _transcriptBuffer.add(transcript);
      _translationBuffer.add(note); // [Architect: Buffer for 15s aggregation]
      notifyListeners();

      // [独立计数器 1: 15s 翻译引擎]
      try {
        if (_translationBuffer.length >= 3) {
          final workingBatch = List<InsightNote>.from(_translationBuffer);
          _translationBuffer.clear();
          unawaited(_performAggregatedTranslation(workingBatch));
        }
      } catch (e) {
        debugPrint("Translation trigger error: $e");
      }

      // [独立计数器 2: 60s 学术摘要] - 自修复步进逻辑
      try {
        final totalCount = _allNotes.where((n) => !n.isSummary).length;
        if (totalCount > 0 && totalCount % 12 == 0) {
          final combinedText = _transcriptBuffer.join(" ");
          if (combinedText.trim().isNotEmpty) {
            final clusterId = _noteBuffer.isNotEmpty ? _noteBuffer.first.clusterId : "tail_${DateTime.now().millisecondsSinceEpoch}";
            _transcriptBuffer.clear();
            _noteBuffer.clear();
            unawaited(_performBatchSummary(combinedText, clusterId));
          }
        }
      } catch (e) {
        debugPrint("Summary trigger error: $e");
      }

    } catch (e) { debugPrint("Process Audio core error: $e"); }
  }

  Future<void> _performAggregatedTranslation(List<InsightNote> workingBatch) async {
    if (workingBatch.isEmpty || _fastAiService == null) return;
    
    // [Staggering] 强制错峰延迟，避免与 STT 或 Summary 同时撞击 API 限制
    await Future.delayed(const Duration(milliseconds: 500));
    
    final combinedText = workingBatch.map((n) => n.transcript).join(" | ");
    
    try {
      // [Architect: Groq Path] 翻译任务强制路由至 Groq，解决 SiliconFlow 翻译乱码问题
      final translationResult = await (_groqService ?? _fastAiService ?? _aiService)!.translate(combinedText);
      if (workingBatch.isNotEmpty) {
        // [Task 3: UI Rhythm Delay] 半秒延迟，抵消 AI 处理的“预判感”，让中文出现更自然
        await Future.delayed(const Duration(milliseconds: 500));
        workingBatch.last.translatedContent = translationResult;
      }
      notifyListeners();
    } catch (e) { 
      debugPrint("Cloud Translation Error ($e), falling back to On-Device..."); 
      try {
        final localTranslation = await _onDeviceTranslator.translateText(combinedText);
        if (workingBatch.isNotEmpty) {
          // [Task 3: UI Rhythm Delay] 本地 Fallback 同样执行节奏延迟
          await Future.delayed(const Duration(milliseconds: 500));
          workingBatch.last.translatedContent = "[Local] $localTranslation";
        }
        notifyListeners();
      } catch (localError) {
        debugPrint("Local Translation Error: $localError");
      }
    }
  }

  Future<void> _performBatchSummary(String combinedText, String? clusterIdToSummary) async {
    // [Architect: Strategic Re-routing] 小结优先走 Groq (Llama-3.3)，追求极致速度与零成本
    final service = _groqService ?? _aiService; 
    if (combinedText.isEmpty || service == null) return;

    // [Staggering] 1分钟小结强制延迟 1s，确保之前的 15s 翻译已经建立连接，避免并发 429
    await Future.delayed(const Duration(seconds: 1));

    final summaryNote = InsightNote(summary: '', transcript: combinedText, timestamp: DateTime.now(), clusterId: clusterIdToSummary, isSummary: true, isProcessing: true);
    _allNotes.add(summaryNote);
    notifyListeners();
    try {
      final summary = await service.summarize(combinedText, previousSummary: _lastSummary, provider: AIProvider.groq, strategy: UserPreferenceManager().currentPromptStrategy);
      _lastSummary = summary;
      summaryNote.summary = summary;
      
      debugPrint("[Track 2] Logic Block Created: ${summary.substring(0, min(20, summary.length))}...");

      // [Shadow Save] 每完成 5 次逻辑聚合，保存一次影子缓存
      final summaryCount = _allNotes.where((n) => n.isSummary).length;
      if (summaryCount > 0 && summaryCount % 5 == 0) {
        unawaited(_saveShadowCache());
      }

      debugPrint("[Haptic] Triggering Light Impact for Track 2.");
      HapticFeedback.lightImpact();
    } catch (e) { summaryNote.summary = "Summary delayed..."; } 
    finally { summaryNote.isProcessing = false; notifyListeners(); }
  }

  // [Architect Fix] 逻辑加锁与字符串脱水
  Future<void> generateFinalAcademicReview() async {
    if (_isGeneratingFinalReview) return; // 拦截重复触发
    final summaryNotes = _allNotes.where((n) => n.isSummary).toList();
    if (summaryNotes.isEmpty || _aiService == null) return;

    _isGeneratingFinalReview = true;
    _finalReviewContent = ""; 
    notifyListeners();

    try {
      // [Stepped Compression] 阶梯压缩逻辑
      String finalMaterial = "";
      if (summaryNotes.length > 15) {
        debugPrint("[Recursive] Triggering Mid-term Digest for ${summaryNotes.length} notes.");
        final toCompress = summaryNotes.take(summaryNotes.length - 5).map((n) => n.summary).join("\n");
        final archive = await _fastAiService!.compressSummaries(toCompress);
        final recentOnes = summaryNotes.skip(summaryNotes.length - 5).map((n) => n.summary).join("\n---\n");
        finalMaterial = "### [Mid-term Digest]\n$archive\n\n### [Recent Details]\n$recentOnes";
      } else {
        // [Dehydration] 字符串脱水：清理重复标题与无效空格，极致节省 Token
        finalMaterial = summaryNotes.map((n) {
          return n.summary.replaceAll(RegExp(r'\s+'), ' ').trim();
        }).join("\n---\n");
      }

      // [Architect: Final Polish] 全篇复盘必须使用最强的 DeepSeek V3 引擎
      final stream = _aiService!.generateFinalAcademicRecapStream(
        finalMaterial, 
        modelOverride: "deepseek-ai/DeepSeek-V3"
      );
      
      String buffer = "";
      int chunkCount = 0;
      bool hasTriggeredHaptic = false;

      await for (final chunk in stream) {
        if (!hasTriggeredHaptic && chunk.trim().isNotEmpty) {
          debugPrint("[Haptic] Triggering Medium Impact for Track 3 Start.");
          // [Haptics] 巅峰复盘首字吐出反馈
          HapticFeedback.mediumImpact();
          hasTriggeredHaptic = true;
        }
        buffer += chunk;
        chunkCount++;
        
        // [Performance] 每收 5 个 Chunk 才刷新一次 UI，防止主线程因过度渲染卡死
        if (chunkCount % 5 == 0) {
          _finalReviewContent = buffer;
          notifyListeners();
        }
      }
      // [Fix] 强制刷新缓冲区，确保流结束后的最后几个字能立即显示
      _finalReviewContent = buffer;
      notifyListeners();

      // 追加全篇原文
      final fullTranscript = _allNotes.where((n) => !n.isSummary).map((n) => n.transcript).join(" ");
      _finalReviewContent = "${_finalReviewContent ?? ""}\n\n---\n\n# Full Transcript\n\n$fullTranscript";
      
      await _saveReviewToFile(_finalReviewContent!);
      
      // [Refined GC] 持久化成功后，异步触发清理
      debugPrint("[GC] Starting Refined Cleanup for ${_tempFilePaths.length} files.");
      unawaited(_cleanupTempFiles()); 
      await _clearShadowCache(); // [Shadow Save] 显式物理删除草稿，防止二次启动提示

      debugPrint("[Haptic] Success Haptic Feedback.");
      // [Haptics] 资产落袋成功反馈
      HapticFeedback.mediumImpact();
      Future.delayed(const Duration(milliseconds: 100), () => HapticFeedback.lightImpact());
    } catch (e) { 
      debugPrint("Final Recap Error: $e");
      _finalReviewContent = "[网络暂时拥堵或 API 响应异常，请稍后手动点击此处重试复盘]"; 
    } finally { 
      _isGeneratingFinalReview = false; 
      notifyListeners(); 
    }
  }

  Future<void> _saveReviewToFile(String content) async {
    try {
      final directory = await getApplicationDocumentsDirectory();
      final timestamp = DateFormat('yyyyMMdd_HHmm').format(DateTime.now());
      String sanitizedTitle = "Lecture_Review_$timestamp";
      final file = File('${directory.path}/$sanitizedTitle.md');
      await file.writeAsString(content);
      _lastExportedPath = sanitizedTitle;
    } catch (e) { debugPrint("Persistence error: $e"); }
  }

  Future<void> _cleanupTempFiles() async {
    for (var path in _tempFilePaths) {
      try {
        final file = File(path);
        if (await file.exists()) {
          await file.delete();
          debugPrint("[GC] Deleted: $path");
        }
      } catch (e) { debugPrint("[GC ERROR] Failed to delete $path: $e"); }
    }
    _tempFilePaths.clear();
  }

  String getApiKeyFor(AIProvider provider) => _apiKeys[provider] ?? "";
}
