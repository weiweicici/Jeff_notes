import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:flutter/foundation.dart';
import 'dart:async';
import 'dart:math';
import 'prompt_provider.dart';
import 'recording_provider.dart';

class OpenAIService {
  final String apiKey;
  final String baseUrl;
  final String defaultModel;
  final String whisperModel;
  
  http.Client _client = http.Client();
  bool _isDisposed = false;

  OpenAIService({
    required this.apiKey,
    required this.baseUrl,
    required this.defaultModel,
    this.whisperModel = 'whisper-large-v3',
  });

  void dispose() {
    _isDisposed = true;
    _client.close();
  }

  Future<T> _retry<T>(Future<T> Function() action, {int maxAttempts = 3}) async {
    int attempts = 0;
    while (true) {
      if (_isDisposed) throw Exception("Service Disposed");
      attempts++;
      try {
        return await action();
      } catch (e) {
        if (_isDisposed || attempts >= maxAttempts) rethrow;
        final waitSeconds = pow(2, attempts - 1).toInt();
        await Future.delayed(Duration(seconds: waitSeconds));
      }
    }
  }

  // [Architect Fix] 强化正则清洗，确保高亮与标题共存
  String _sanitizeResponse(String text) {
    String cleaned = text.trim();
    
    // 移除 AI 习惯性的引导前缀
    final preambleRegex = RegExp(r'^(Here is the review:|Review:|Analysis:|以下是复盘报告[:：])', caseSensitive: false);
    cleaned = cleaned.replaceFirst(preambleRegex, '').trim();

    // 移除 ``` 围栏，但保留内容（防止部分模型无视禁令）
    final fenceRegex = RegExp(r'```[a-zA-Z]*\n?|```');
    cleaned = cleaned.replaceAll(fenceRegex, '').trim();
    
    // 确保 Markdown 标题符 # 后有空格，防止渲染失效
    final titleRegex = RegExp(r'^(#+)([^#\s])', multiLine: true);
    cleaned = cleaned.replaceAllMapped(titleRegex, (match) => '${match.group(1)} ${match.group(2)}');

    // 注意：此处不再移除 ** 或 == 符号，以支持架构师要求的结语高亮
    return cleaned;
  }

  Future<String?> transcribe(String filePath) async {
    try {
      final file = File(filePath);
      if (!await file.exists()) return null;
      if (await file.length() < 500) return ""; 
    } catch (e) { return null; }

    return await _retry(() async {
      final url = Uri.parse("$baseUrl/audio/transcriptions");
      final request = http.MultipartRequest("POST", url)
        ..headers['Authorization'] = 'Bearer $apiKey'
        ..fields['model'] = whisperModel
        ..fields['response_format'] = 'json'
        ..fields['language'] = 'en'
        ..files.add(await http.MultipartFile.fromPath('file', filePath));

      final streamedResponse = await _client.send(request).timeout(const Duration(seconds: 30));
      final response = await http.Response.fromStream(streamedResponse);

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['text'] ?? "";
      } else {
        throw Exception("STT HTTP ${response.statusCode}");
      }
    });
  }

  Future<String> translate(String text, {String? modelOverride}) async {
    return await _retry(() async {
      final url = Uri.parse("$baseUrl/chat/completions");
      final response = await _client.post(
        url,
        headers: {
          'Authorization': 'Bearer $apiKey',
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          "model": modelOverride ?? defaultModel,
          "messages": [
            {"role": "system", "content": PromptProvider.getTranslatePrompt()},
            {"role": "user", "content": text}
          ],
          "temperature": 0.1,
          "max_tokens": 300,
        }),
      ).timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return _sanitizeResponse(data['choices'][0]['message']['content'].toString());
      } else {
        throw Exception("Translate HTTP ${response.statusCode}");
      }
    });
  }

  Future<String> summarize(
    String currentText, {
    String? previousSummary,
    required AIProvider provider,
    PromptStrategy strategy = PromptStrategy.toeflIelts,
    String? modelOverride,
  }) async {
    return await _retry(() async {
      final url = Uri.parse("$baseUrl/chat/completions");
      final contextContent = PromptProvider.getContextPrompt(previousSummary);
      
      final response = await _client.post(
        url,
        headers: {
          'Authorization': 'Bearer $apiKey',
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          "model": modelOverride ?? defaultModel,
          "messages": [
            {"role": "system", "content": PromptProvider.getSystemPrompt(strategy, provider)},
            {"role": "user", "content": "Context: $contextContent\n\nText: $currentText"}
          ],
          "temperature": 0.4,
          "max_tokens": 600,
        }),
      ).timeout(const Duration(seconds: 30));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final rawContent = data['choices'][0]['message']['content'].toString();
        return _sanitizeResponse(rawContent);
      } else {
        throw Exception("Summary HTTP ${response.statusCode}");
      }
    });
  }

  // [Stepped Compression] 中期归档执行
  Future<String> compressSummaries(String material) async {
    return await _retry(() async {
      final url = Uri.parse("$baseUrl/chat/completions");
      final response = await _client.post(
        url,
        headers: {
          'Authorization': 'Bearer $apiKey',
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          "model": defaultModel,
          "messages": [
            {"role": "system", "content": PromptProvider.getMidTermArchivePrompt()},
            {"role": "user", "content": material}
          ],
          "temperature": 0.3,
        }),
      ).timeout(const Duration(seconds: 30));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return _sanitizeResponse(data['choices'][0]['message']['content'].toString());
      } else {
        throw Exception("Compress HTTP ${response.statusCode}");
      }
    });
  }

  Stream<String> generateFinalAcademicRecapStream(String summaryListText, {String? modelOverride}) async* {
    final url = Uri.parse("$baseUrl/chat/completions");
    final request = http.Request("POST", url);
    request.headers.addAll({
      'Authorization': 'Bearer $apiKey',
      'Content-Type': 'application/json',
      'Accept': 'text/event-stream',
    });
    request.body = jsonEncode({
      "model": modelOverride ?? defaultModel,
      "messages": [
        {"role": "system", "content": PromptProvider.getFinalReviewPrompt()},
        {"role": "user", "content": "Summary List: $summaryListText"}
      ],
      "temperature": 0.3,
      "stream": true,
    });

    final response = await _client.send(request);
    if (response.statusCode != 200) {
      yield "Recap service temporarily unavailable.";
      return;
    }

    await for (final line in response.stream.transform(utf8.decoder).transform(const LineSplitter())) {
      if (line.startsWith("data: ")) {
        final dataStr = line.substring(6).trim();
        if (dataStr == "[DONE]") break;
        try {
          final decoded = jsonDecode(dataStr);
          final content = decoded['choices'][0]['delta']['content'] ?? "";
          yield content;
        } catch (e) {
          debugPrint("SSE Decode Error: $e");
        }
      }
    }
  }
}
