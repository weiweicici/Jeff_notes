import 'recording_provider.dart';

enum PromptStrategy { general, toeflIelts, scientific, humanities }

class PromptProvider {
  static String getSystemPrompt(PromptStrategy strategy, AIProvider provider) {
    return """Role: 学术考点分析专家 (60s 语义滑动窗口)
Context: [前文背景]: {{previousSummary}} | [当前文本]: {{combinedText}}
Task: 结合上下文提取这 60s 的考点，严格遵守：
1. **强制换行**：每个模块输出后必须紧跟两个换行符 (\n\n)，确保在 Markdown 中独立成段。
2. **禁令：禁列表堆叠**。对于 [D] 细节硬化，必须将相关信息合并为一行，使用逗号分隔。严禁将每个单词或短语分成独立行。
3. **动态显示**：仅输出有内容的模块。
4. **格式定义**（严格遵守加粗与双换行）：
**[P] 核心命题**: (主旨内容)

**[K] 信号/定义**: (术语/关键词)

**[D] 细节硬化**: (数据/专有名词/实验，必须单行逗号分隔)

**[L] 逻辑关联**: (因果/对比)

语言：专业学术中文，禁止输出英文原词。""";
  }

  static String getTranslatePrompt() {
    return """# Role: Senior Academic Translator
# Task: Translate 15s lecture segment into Professional Chinese.
# Rules:
1. PURE CHINESE ONLY: Output ONLY Chinese characters. Strictly forbid English words, brackets, or phonetic symbols.
2. Academic Tone: Use formal, high-level lecture vocabulary.
3. No Prediction: Do not guess the end of the sentence.
4. If noise, return empty string.""";
  }

  static String getContextPrompt(String? previousSummary) {
    if (previousSummary == null || previousSummary.isEmpty) return "";
    return "[Anchor: $previousSummary]";
  }

  // [Architect Fix] 极简 XML 模式 - 全篇复盘
  // [Recursive Context] 中期逻辑回顾指令
  static String getMidTermArchivePrompt() {
    return """# Role: 学术档案压缩专家
# Task: 将输入的多个分段摘要压缩为 300 字以内的 [Mid-term Digest]。

# Requirements:
1. **Data Hardening**: 严禁丢弃任何原始摘要中的硬核数据、百分比、术语、人名。
2. **Binary Preservation**: 如果原始摘要中有对比维度（A vs B），必须在压缩稿中予以保留。
3. **Logical Continuity**: 补全分段间的逻辑跳跃，维持讲座的论证链条。
4. 语言：专业学术中文。
No intro/outro.""";
  }

  static String getFinalReviewPrompt() {
    return """# Role: Jeff Notes V1.2 Core Engine
# Task: Summarize below into BLUF structure.

<Rules>
1. Language: All output MUST be in Professional Academic Chinese (专业学术中文).
2. IA Order: Final Synthesis (Bold), Core Topic, Attitude, Binary Table, Logical Framework, Questions.
3. Table Policy: If no clear binary contrast exists, you MUST generate a 2x2 comparison table using [Current Status] vs [Prospect Future]. DO NOT skip the table section.
4. Traceability: If [Mid-term Digest] exists, label its sections in Logical Framework as (Phase 1: Summarized). Keep this tag in English.
5. Format: Output strictly in Markdown. No intro/outro.
</Rules>

# Start Final Synthesis:
""";
  }
}
